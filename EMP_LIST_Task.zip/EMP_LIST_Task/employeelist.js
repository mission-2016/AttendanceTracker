/**
 * 
 */
var employeeApp = angular.module("employeelistApp", [ 'ngRoute', 'ngResource' ])
.constant('METHOD_POST', '&method=POST')
.constant('METHOD_GET', '&method=GET');


/**
 * @method 	Controller method [dbconfigCtrl]
 * @Desc 	'This API method will data sync b/w View to server.'
 * @return 	data object / mg-model.
 */
employeeApp.controller("employeelistCtrl", [ '$scope', '$location', '$http','$routeParams',
		function($scope, $location, $http, $routeParams) {
			
			console.log("================ clicked Employee list controller................../11111111111");
		    $scope.selection = [];
		    
		    $scope.selected = function (id) {
		    	console.log("================ /1");
		    };  		    
		} 
]);
